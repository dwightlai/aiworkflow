package com.aiworkflow.knowledge.service;

import com.aiworkflow.model.domain.ModelProvider;
import com.aiworkflow.model.service.ModelProviderService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Component
public class ModelProviderEmbeddingClient implements EmbeddingClient {
    private final ModelProviderService modelProviderService;
    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;

    @Autowired
    public ModelProviderEmbeddingClient(ModelProviderService modelProviderService, ObjectMapper objectMapper) {
        this(modelProviderService, objectMapper, HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build());
    }

    ModelProviderEmbeddingClient(
            ModelProviderService modelProviderService,
            ObjectMapper objectMapper,
            HttpClient httpClient
    ) {
        this.modelProviderService = modelProviderService;
        this.objectMapper = objectMapper;
        this.httpClient = httpClient;
    }

    @Override
    public List<Double> embed(String providerId, String model, String text) {
        ModelProvider provider = modelProviderService.get(providerId);
        validateProvider(provider);
        String actualModel = firstNonBlank(provider.model(), model);
        if (actualModel == null) {
            throw new IllegalStateException("Embedding model is required for provider: " + providerId);
        }
        if ("OLLAMA".equalsIgnoreCase(provider.modelType())) {
            return embedWithOllama(provider, actualModel, text == null ? "" : text);
        }
        throw new IllegalStateException("Unsupported embedding model type: " + provider.modelType());
    }

    @Override
    public List<List<Double>> embedAll(String providerId, String model, List<String> texts) {
        ModelProvider provider = modelProviderService.get(providerId);
        validateProvider(provider);
        String actualModel = firstNonBlank(provider.model(), model);
        if (actualModel == null) {
            throw new IllegalStateException("Embedding model is required for provider: " + providerId);
        }
        if (!"OLLAMA".equalsIgnoreCase(provider.modelType())) {
            return EmbeddingClient.super.embedAll(providerId, model, texts);
        }
        Map<String, Object> request = new LinkedHashMap<>();
        request.put("model", actualModel);
        request.put("input", texts.stream().map(text -> text == null ? "" : text).toList());
        HttpResponse<String> response = postJson(normalizeEndpoint(provider.baseUrl()) + "/api/embed", request);
        assertSuccessful(response, "/api/embed");
        return parseOllamaBatchEmbeddings(response.body());
    }

    private List<Double> embedWithOllama(ModelProvider provider, String model, String text) {
        String endpoint = normalizeEndpoint(provider.baseUrl());
        Map<String, Object> embeddingsRequest = new LinkedHashMap<>();
        embeddingsRequest.put("model", model);
        embeddingsRequest.put("prompt", text);
        HttpResponse<String> response = postJson(endpoint + "/api/embeddings", embeddingsRequest);
        if (response.statusCode() == 404) {
            Map<String, Object> embedRequest = new LinkedHashMap<>();
            embedRequest.put("model", model);
            embedRequest.put("input", text);
            response = postJson(endpoint + "/api/embed", embedRequest);
            assertSuccessful(response, "/api/embed");
            return parseOllamaBatchEmbedding(response.body());
        }
        assertSuccessful(response, "/api/embeddings");
        return parseEmbedding(response.body(), "embedding");
    }

    private HttpResponse<String> postJson(String uri, Map<String, Object> body) {
        try {
            HttpRequest request = HttpRequest.newBuilder(URI.create(uri))
                    .timeout(Duration.ofMinutes(2))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofByteArray(objectMapper.writeValueAsBytes(body)))
                    .build();
            return httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to call embedding provider", exception);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Embedding provider call was interrupted", exception);
        }
    }

    private List<Double> parseOllamaBatchEmbedding(String body) {
        return parseOllamaBatchEmbeddings(body).get(0);
    }

    private List<List<Double>> parseOllamaBatchEmbeddings(String body) {
        try {
            JsonNode embeddings = objectMapper.readTree(body).path("embeddings");
            if (!embeddings.isArray() || embeddings.isEmpty()) {
                throw new IllegalStateException("Ollama embedding response does not contain embeddings");
            }
            List<List<Double>> results = new ArrayList<>(embeddings.size());
            for (JsonNode embedding : embeddings) {
                results.add(toDoubleList(embedding));
            }
            return results;
        } catch (JsonProcessingException exception) {
            throw new IllegalStateException("Unable to parse Ollama embedding response", exception);
        }
    }

    private List<Double> parseEmbedding(String body, String fieldName) {
        try {
            return toDoubleList(objectMapper.readTree(body).path(fieldName));
        } catch (JsonProcessingException exception) {
            throw new IllegalStateException("Unable to parse embedding response", exception);
        }
    }

    private List<Double> toDoubleList(JsonNode node) {
        if (!node.isArray() || node.isEmpty()) {
            throw new IllegalStateException("Embedding response does not contain a vector");
        }
        List<Double> embedding = new ArrayList<>(node.size());
        for (JsonNode value : node) {
            embedding.add(value.asDouble());
        }
        return embedding;
    }

    private void assertSuccessful(HttpResponse<String> response, String path) {
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new IllegalStateException("Embedding provider request failed at " + path + ": "
                    + response.statusCode() + " " + response.body());
        }
    }

    private void validateProvider(ModelProvider provider) {
        if (!provider.enabled()) {
            throw new IllegalStateException("Embedding provider is disabled: " + provider.id());
        }
        if (!"EMBEDDING".equalsIgnoreCase(provider.modelUsage())) {
            throw new IllegalStateException("Model provider is not configured for embeddings: " + provider.id());
        }
        if (provider.baseUrl() == null || provider.baseUrl().isBlank()) {
            throw new IllegalStateException("Embedding provider base URL is required: " + provider.id());
        }
    }

    private String normalizeEndpoint(String endpoint) {
        String normalized = endpoint.strip();
        return normalized.endsWith("/") ? normalized.substring(0, normalized.length() - 1) : normalized;
    }

    private String firstNonBlank(String first, String second) {
        if (first != null && !first.isBlank()) {
            return first.strip();
        }
        if (second != null && !second.isBlank()) {
            return second.strip();
        }
        return null;
    }
}
