package com.aiworkflow.model.persistence;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ModelProviderMapper extends BaseMapper<ModelProviderEntity> {
}
