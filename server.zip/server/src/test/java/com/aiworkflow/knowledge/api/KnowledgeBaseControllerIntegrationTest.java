package com.aiworkflow.knowledge.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.aiworkflow.knowledge.service.ElasticsearchVectorStoreClient;
import com.aiworkflow.knowledge.service.EmbeddingClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.mock.web.MockMultipartFile;

import java.util.List;

import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(
        properties = {
                "spring.autoconfigure.exclude="
                        + "org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration,"
                        + "org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration"
        })
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class KnowledgeBaseControllerIntegrationTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ElasticsearchVectorStoreClient elasticsearchVectorStoreClient;

    @MockBean
    private EmbeddingClient embeddingClient;

    @BeforeEach
    void setUpEmbeddingClient() {
        when(embeddingClient.embed(anyString(), anyString(), anyString())).thenReturn(List.of(0.1, 0.2, 0.3));
        when(embeddingClient.embedAll(anyString(), anyString(), anyList())).thenReturn(List.of(List.of(0.1, 0.2, 0.3)));
    }

    @Test
    void createsKnowledgeBaseAndIngestsDocuments() throws Exception {
        String response = mockMvc.perform(post("/api/knowledge-bases")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"产品手册","description":"客服知识库"}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.retrievalMode").value("HYBRID"))
                .andExpect(jsonPath("$.data.name").value("产品手册"))
                .andReturn()
                .getResponse()
                .getContentAsString();

        String knowledgeBaseId = new ObjectMapper().readTree(response).path("data").path("id").asText();

        mockMvc.perform(post("/api/knowledge-bases/{id}/documents", knowledgeBaseId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"退换货政策.txt","content":"七天无理由退货。质量问题支持免费换货。"}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.chunkCount").value(1));

        mockMvc.perform(get("/api/knowledge-bases"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.items[0].documentCount").value(1))
                .andExpect(jsonPath("$.data.items[0].chunkCount").value(1));
    }

    @Test
    void searchesKnowledgeBaseChunks() throws Exception {
        String response = mockMvc.perform(post("/api/knowledge-bases")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"售后知识库","description":null}
                                """))
                .andExpect(status().isOk())
                .andReturn()
                .getResponse()
                .getContentAsString();

        String knowledgeBaseId = new ObjectMapper().readTree(response).path("data").path("id").asText();

        mockMvc.perform(post("/api/knowledge-bases/{id}/documents", knowledgeBaseId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"policy.txt","content":"发票可以在订单完成后七日内申请。会员积分不可兑换现金。"}
                                """))
                .andExpect(status().isOk());

        mockMvc.perform(post("/api/knowledge-bases/{id}/search", knowledgeBaseId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"query":"发票申请","topK":3}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data[0].documentName").value("policy.txt"))
                .andExpect(jsonPath("$.data[0].content").value("发票可以在订单完成后七日内申请。会员积分不可兑换现金。"));
    }
    @Test
    void managesVectorStoreConfigsAndKnowledgeBaseRetrievalSettings() throws Exception {
        mockMvc.perform(post("/api/vector-store-configs")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"local-memory","storeType":"MEMORY","endpoint":"","indexName":"aiworkflow_kb","enabled":true}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.name").value("local-memory"))
                .andExpect(jsonPath("$.data.storeType").value("MEMORY"));

        mockMvc.perform(get("/api/vector-store-configs"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.items[0].indexName").value("aiworkflow_kb"));

        mockMvc.perform(post("/api/knowledge-bases")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"support-kb","description":"support docs","embeddingModelId":"model_embed","vectorStoreConfigId":"vector_1","vectorDimension":1536,"splitterType":"MARKDOWN_HEADING","chunkSize":160,"chunkOverlap":20,"retrievalMode":"HYBRID","topK":5}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.embeddingModelId").value("model_embed"))
                .andExpect(jsonPath("$.data.vectorStoreConfigId").value("vector_1"))
                .andExpect(jsonPath("$.data.vectorDimension").value(1536))
                .andExpect(jsonPath("$.data.splitterType").value("SIMPLE_TEXT"))
                .andExpect(jsonPath("$.data.chunkSize").value(500))
                .andExpect(jsonPath("$.data.chunkOverlap").value(50))
                .andExpect(jsonPath("$.data.retrievalMode").value("HYBRID"))
                .andExpect(jsonPath("$.data.topK").value(3));
    }

    @Test
    void previewsAndListsDocumentChunksBeforeIngestion() throws Exception {
        mockMvc.perform(post("/api/knowledge-bases/chunks/preview")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"content":"# Refund\\nRefund requests are handled within seven days.\\n\\n# Invoice\\nInvoices can be downloaded after payment.","splitterType":"MARKDOWN_HEADING","chunkSize":80,"chunkOverlap":10}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data[0].content").value("# Refund\nRefund requests are handled within seven days."))
                .andExpect(jsonPath("$.data[1].content").value("# Invoice\nInvoices can be downloaded after payment."))
                .andExpect(jsonPath("$.data[0].tokenEstimate").isNumber());

        String response = mockMvc.perform(post("/api/knowledge-bases")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"chunk-kb","description":null}
                                """))
                .andExpect(status().isOk())
                .andReturn()
                .getResponse()
                .getContentAsString();

        String knowledgeBaseId = new ObjectMapper().readTree(response).path("data").path("id").asText();
        String documentResponse = mockMvc.perform(post("/api/knowledge-bases/{id}/documents", knowledgeBaseId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"kb.md","content":"# Refund\\nRefund requests are handled within seven days.","splitterType":"MARKDOWN_HEADING","chunkSize":80,"chunkOverlap":10}
                                """))
                .andExpect(status().isOk())
                .andReturn()
                .getResponse()
                .getContentAsString();

        String documentId = new ObjectMapper().readTree(documentResponse).path("data").path("id").asText();

        mockMvc.perform(get("/api/knowledge-bases/{id}/documents/{documentId}/chunks", knowledgeBaseId, documentId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.items[0].documentId").value(documentId))
                .andExpect(jsonPath("$.data.items[0].enabled").value(true))
                .andExpect(jsonPath("$.data.items[0].tokenEstimate").isNumber());
    }

    @Test
    void uploadsDocumentFileExtractsTextAndIngestsChunks() throws Exception {
        String response = mockMvc.perform(post("/api/knowledge-bases")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"file-kb","description":null,"splitterType":"SIMPLE_TEXT","chunkSize":40,"chunkOverlap":0}
                                """))
                .andExpect(status().isOk())
                .andReturn()
                .getResponse()
                .getContentAsString();
        String knowledgeBaseId = new ObjectMapper().readTree(response).path("data").path("id").asText();
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "policy.txt",
                MediaType.TEXT_PLAIN_VALUE,
                "Refund requests are handled within seven days.\nInvoices are available after payment.".getBytes()
        );

        mockMvc.perform(multipart("/api/knowledge-bases/documents/upload/preview")
                        .file(file)
                        .param("splitterType", "SIMPLE_TEXT")
                        .param("chunkSize", "40")
                        .param("chunkOverlap", "0"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.fileName").value("policy.txt"))
                .andExpect(jsonPath("$.data.characterCount").value(84))
                .andExpect(jsonPath("$.data.chunks[0].content").value("Refund requests are handled within seven"));

        String documentResponse = mockMvc.perform(multipart("/api/knowledge-bases/{id}/documents/upload", knowledgeBaseId)
                        .file(file)
                        .param("splitterType", "SIMPLE_TEXT")
                        .param("chunkSize", "40")
                        .param("chunkOverlap", "0"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.name").value("policy.txt"))
                .andExpect(jsonPath("$.data.chunkCount").value(3))
                .andReturn()
                .getResponse()
                .getContentAsString();

        String documentId = new ObjectMapper().readTree(documentResponse).path("data").path("id").asText();
        mockMvc.perform(get("/api/knowledge-bases/{id}/documents/{documentId}/chunks", knowledgeBaseId, documentId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.items[0].content").value("Refund requests are handled within seven"))
                .andExpect(jsonPath("$.data.items[1].content").value("days.\nInvoices are available after paym"));
    }

    @Test
    void updatesChunksAndDeletesDocuments() throws Exception {
        String response = mockMvc.perform(post("/api/knowledge-bases")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"editable-kb","description":null}
                                """))
                .andExpect(status().isOk())
                .andReturn()
                .getResponse()
                .getContentAsString();
        String knowledgeBaseId = new ObjectMapper().readTree(response).path("data").path("id").asText();

        String documentResponse = mockMvc.perform(post("/api/knowledge-bases/{id}/documents", knowledgeBaseId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"faq.txt","content":"Refund requests are handled within seven days."}
                                """))
                .andExpect(status().isOk())
                .andReturn()
                .getResponse()
                .getContentAsString();
        String documentId = new ObjectMapper().readTree(documentResponse).path("data").path("id").asText();

        String chunksResponse = mockMvc.perform(get("/api/knowledge-bases/{id}/documents/{documentId}/chunks", knowledgeBaseId, documentId))
                .andExpect(status().isOk())
                .andReturn()
                .getResponse()
                .getContentAsString();
        String chunkId = new ObjectMapper().readTree(chunksResponse).path("data").path("items").path(0).path("id").asText();

        mockMvc.perform(put("/api/knowledge-bases/{id}/chunks/{chunkId}", knowledgeBaseId, chunkId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"content":"Refund requests are handled within five days.","enabled":false}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.content").value("Refund requests are handled within five days."))
                .andExpect(jsonPath("$.data.enabled").value(false));

        mockMvc.perform(post("/api/knowledge-bases/{id}/search", knowledgeBaseId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"query":"Refund","topK":3}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.length()").value(0));

        mockMvc.perform(delete("/api/knowledge-bases/{id}/documents/{documentId}", knowledgeBaseId, documentId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));

        mockMvc.perform(get("/api/knowledge-bases/{id}/documents", knowledgeBaseId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.total").value(0));

        mockMvc.perform(get("/api/knowledge-bases"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.items[0].documentCount").value(0))
                .andExpect(jsonPath("$.data.items[0].chunkCount").value(0));
    }

    @Test
    void updatesVectorStoreConfigs() throws Exception {
        String response = mockMvc.perform(post("/api/vector-store-configs")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"Elastic dev","storeType":"ELASTICSEARCH","endpoint":"http://localhost:9200","indexName":"kb_dev","username":"elastic","password":"secret","connectTimeoutMs":7000,"readTimeoutMs":45000,"enabled":true}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.username").value("elastic"))
                .andExpect(jsonPath("$.data.passwordConfigured").value(true))
                .andExpect(jsonPath("$.data.password").doesNotExist())
                .andExpect(jsonPath("$.data.connectTimeoutMs").value(7000))
                .andReturn()
                .getResponse()
                .getContentAsString();
        String vectorStoreId = new ObjectMapper().readTree(response).path("data").path("id").asText();

        mockMvc.perform(put("/api/vector-store-configs/{id}", vectorStoreId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"Elastic prod","storeType":"ELASTICSEARCH","endpoint":"https://es.example.com","indexName":"kb_prod","username":"elastic-prod","connectTimeoutMs":9000,"readTimeoutMs":60000,"enabled":false}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.name").value("Elastic prod"))
                .andExpect(jsonPath("$.data.endpoint").value("https://es.example.com"))
                .andExpect(jsonPath("$.data.username").value("elastic-prod"))
                .andExpect(jsonPath("$.data.passwordConfigured").value(true))
                .andExpect(jsonPath("$.data.readTimeoutMs").value(60000))
                .andExpect(jsonPath("$.data.enabled").value(false));
    }

    @Test
    void deletesVectorStoreConfigs() throws Exception {
        String response = mockMvc.perform(post("/api/vector-store-configs")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"Elastic temporary","storeType":"ELASTICSEARCH","endpoint":"http://localhost:9200","indexName":"kb_tmp","enabled":true}
                                """))
                .andExpect(status().isOk())
                .andReturn()
                .getResponse()
                .getContentAsString();
        String vectorStoreId = new ObjectMapper().readTree(response).path("data").path("id").asText();

        mockMvc.perform(delete("/api/vector-store-configs/{id}", vectorStoreId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));

        mockMvc.perform(get("/api/vector-store-configs"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.items[?(@.id == '" + vectorStoreId + "')]").isEmpty());
    }

    @Test
    void updatesAndDeletesKnowledgeBases() throws Exception {
        String response = mockMvc.perform(post("/api/knowledge-bases")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"ops-kb","description":"draft docs","splitterType":"SIMPLE_TEXT","chunkSize":300,"chunkOverlap":20,"retrievalMode":"KEYWORD","topK":3}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.splitterType").value("SIMPLE_TEXT"))
                .andExpect(jsonPath("$.data.chunkSize").value(500))
                .andExpect(jsonPath("$.data.chunkOverlap").value(50))
                .andExpect(jsonPath("$.data.retrievalMode").value("HYBRID"))
                .andExpect(jsonPath("$.data.topK").value(3))
                .andReturn()
                .getResponse()
                .getContentAsString();
        String knowledgeBaseId = new ObjectMapper().readTree(response).path("data").path("id").asText();

        mockMvc.perform(post("/api/knowledge-bases/{id}/documents", knowledgeBaseId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"runbook.txt","content":"Restart service after checking health probes."}
                                """))
                .andExpect(status().isOk());

        mockMvc.perform(put("/api/knowledge-bases/{id}", knowledgeBaseId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"ops-kb-prod","description":"production docs","embeddingModelId":"embed-prod","vectorStoreConfigId":"vector-prod","vectorDimension":3072,"splitterType":"MARKDOWN_HEADING","chunkSize":180,"chunkOverlap":30,"retrievalMode":"HYBRID","topK":6}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.name").value("ops-kb-prod"))
                .andExpect(jsonPath("$.data.description").value("production docs"))
                .andExpect(jsonPath("$.data.embeddingModelId").value("embed-prod"))
                .andExpect(jsonPath("$.data.vectorStoreConfigId").value("vector-prod"))
                .andExpect(jsonPath("$.data.vectorDimension").value(3072))
                .andExpect(jsonPath("$.data.splitterType").value("SIMPLE_TEXT"))
                .andExpect(jsonPath("$.data.chunkSize").value(500))
                .andExpect(jsonPath("$.data.chunkOverlap").value(50))
                .andExpect(jsonPath("$.data.retrievalMode").value("HYBRID"))
                .andExpect(jsonPath("$.data.topK").value(3))
                .andExpect(jsonPath("$.data.documentCount").value(1))
                .andExpect(jsonPath("$.data.chunkCount").value(1));

        mockMvc.perform(delete("/api/knowledge-bases/{id}", knowledgeBaseId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));

        mockMvc.perform(get("/api/knowledge-bases"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.total").value(0));
    }
}
