-- 档案编研样例数据：任务初始化示例
INSERT INTO research_compile_task_mock(task_code, template_code, task_name)
VALUES
('TASK_CHRONICLE_2025', 'archive_chronicle', '生成某某集团2025年度大事记'),
('TASK_YEARBOOK_2025', 'archive_yearbook', '生成某某集团2025年年鉴'),
('TASK_TOPIC_DA_DIGITAL', 'archive_topic_collection', '生成档案数字化建设专题资料汇编');
